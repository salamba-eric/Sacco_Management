Mozzle, a savings and credit cooperative that is dedicated to providing not only finances, but also financial advice. Customer satisfaction is key, at 
Mozzle.
The web page shows the several services offered at Mozzle, the team and contacts for reaching out. A good UI goes along way in enhancing better user 
experience as well as good interactivity. The key thing for the website is the 'apply now' button for loan applications. The webpage has most of the 
basics of any website; 'home', 'services', 'contact' and 'team'. The extensive use of bootstrap has gone a long way in bringing out the best on the page.
